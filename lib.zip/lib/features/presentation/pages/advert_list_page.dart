import 'dart:developer' as dev;
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_deriv_bloc_manager/bloc_managers/bloc_manager.dart';
import 'package:flutter_derivp2p_sample/core/states/api_connection_cubit.dart';

/// Advert Listing Page
class AdvertListPage extends StatefulWidget {
  /// Initialise AdvertListPage
  const AdvertListPage({Key? key}) : super(key: key);

  /// Route Page route name.
  static const String routeName = 'advert_list_page';

  @override
  _AdvertListPageState createState() => _AdvertListPageState();
}

class _AdvertListPageState extends State<AdvertListPage> {
  late ApiConnectionCubit _apiConnectionCubit;

  @override
  void initState() {
    super.initState();

    _apiConnectionCubit = BlocManager.instance.fetch<ApiConnectionCubit>();
    _apiConnectionCubit.initialize();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
          body: BlocBuilder<ApiConnectionCubit, ApiConnectionState>(
        bloc: _apiConnectionCubit,
        builder: (BuildContext context, ApiConnectionState state) {
          dev.log('currentstate : $state');
          if (state is ApiConnectionConnectedState) {
            return const Center(child: Text('Advert List'));
          }
          return Container();
        },
      ));
}
