import 'package:flutter/material.dart';
import 'package:flutter_deriv_api/basic_api/generated/ping_send.dart';
import 'package:flutter_deriv_api/basic_api/request.dart';
import 'package:flutter_deriv_api/basic_api/response.dart';
import 'package:flutter_deriv_api/services/connection/api_manager'
    '/binary_api.dart' as deriv_api;
import 'package:flutter_deriv_api/services/connection/api_manager/connection_information.dart';
import 'package:flutter_derivp2p_sample/core/helpers/json_helper.dart';
import 'package:flutter_derivp2p_sample/deriv_connection/interceptor.dart';
import 'package:web_socket_channel/io.dart';

/// BinaryAPIWrapper
class BinaryAPIWrapper {
  /// Constructs a new BinaryAPIWrapper.
  BinaryAPIWrapper({
    required UniqueKey uniqueKey,
    required this.interceptor,
  }) {
    _derivAPI = deriv_api.BinaryAPI(uniqueKey);
  }

  /// The interceptor to intercept the request and response.
  final Interceptor? interceptor;

  late final deriv_api.BinaryAPI _derivAPI;

  /// ping wrapper api
  Future<Map<String, dynamic>> ping() => _derivAPICall(const PingRequest());

  /// derive wrapper api call
  Future<Map<String, dynamic>> _derivAPICall(Request request) async {
    interceptor?.onRequest(request.toJson());

    final Response response = await _derivAPI.call<Response>(request: request);

    return _normalizeErrorObject(response);
  }

  Map<String, dynamic> _normalizeErrorObject(Response response) {
    final Map<String, dynamic> rawResponse = JSONHelper.decode(
      JSONHelper.encode(response.toJson()),
      convertObjectToArrayKeys: <String>[
        'p2p_payment_methods',
        'p2p_advertiser_payment_methods',
        'payment_method_details',
        'fields',
      ],
    );

    if (rawResponse['error'] == null) {
      rawResponse.remove('error');
    }

    interceptor?.handleResponse(rawResponse);

    return rawResponse;
  }

  /// Connects to API
  Future<IOWebSocketChannel?> run({
    void Function(UniqueKey? uniqueKey)? onError,
    void Function(UniqueKey? uniqueKey)? onDone,
    void Function(UniqueKey? uniqueKey)? onOpen,
  }) async {
    final ConnectionInformation connectionInformation = ConnectionInformation(
        endpoint: 'frontend.binaryws.com', appId: '1089', brand: 'deriv');

    await _derivAPI.connect(
      connectionInformation,
      onOpen: onOpen?.call,
      onDone: onDone?.call,
      onError: onError?.call,
    );
  }

  /// Disconnects from API
  Future<void> close() async {
    await _derivAPI.disconnect();
  }
}
