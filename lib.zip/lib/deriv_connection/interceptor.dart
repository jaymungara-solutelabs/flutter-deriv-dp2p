// Todo(farzin): This module needs refactoring.
// - It should be part of BinaryAPI, Not account.
// - Anyone should be able to define interceptor, currently BinaryAPI supports
// just one.
// - Interceptors should be able to transform the outgoing request and incoming
// response.

import 'dart:convert';
import 'dart:developer' as dev;

import 'package:flutter_derivp2p_sample/core/states/api_connection_cubit.dart';
import 'package:flutter_derivp2p_sample/deriv_connection/api_error.dart';
import 'package:flutter_derivp2p_sample/deriv_connection/base_interceptor.dart';

/// This class will intercept all web socket communications and raise the
/// relevant callback.
class Interceptor extends BaseInterceptor {
  /// Constructs a new Interceptor with the given parameter.
  Interceptor(
    this._apiConnectionCubit,
  );

  final ApiConnectionCubit _apiConnectionCubit;

  @override
  bool handleResponse(Map<String, dynamic> response) {
    if (response['error'] != null) {
      return onError(APIError.fromMap(response['error']));
    } else {
      return onSuccess(response);
    }
  }

  @override
  void onRequest(Map<String, dynamic> req) {
    dev.log('Queuing outgoing request: ${jsonEncode(req)}');
  }

  @override
  bool onError(APIError error) {
    // after refactoring DerivConnectionBloc and removing
    // ConnectionDisableAccountEvent and ConnectionForcedLogoutState.
    if (error.isP2PDisabled || error.isUserUnwelcome || error.isUserDisabled) {
      _apiConnectionCubit.emit(ApiConnectionDisconnectedState(error: error));
      // _apiConnectionCubit.add(ConnectionAPIErrorEvent(error: error));
      return false;
    } else if (error.isUserAccessDenied) {
      // _apiConnectionCubit.add(ConnectionDisableAccountEvent(error: error));
      _apiConnectionCubit.handleConnectionDisableAccountEvent(error);
      return false;
    }

    return true;
  }
}
