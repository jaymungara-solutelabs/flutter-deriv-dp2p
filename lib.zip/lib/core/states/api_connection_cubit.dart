import 'dart:developer' as dev;

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_derivp2p_sample/core/bloc_manager/event_listeners/connection_event_listener.dart';
import 'package:flutter_derivp2p_sample/deriv_connection/api_error.dart';
import 'package:flutter_derivp2p_sample/deriv_connection/binary_api_wrapper.dart';
import 'package:flutter_derivp2p_sample/deriv_connection/interceptor.dart';
import 'package:flutter_derivp2p_sample/service/connection_service.dart';
import 'package:flutter_derivp2p_sample/utils/enums.dart';

part 'api_connection_state.dart';

/// Api Connection Cubit
class ApiConnectionCubit extends Cubit<ApiConnectionState>
    implements ConnectionEventListener {
  /// Initializes api connection state.
  ApiConnectionCubit() : super(ApiConnectionInitialState());

  late BinaryAPIWrapper _api;

  /// Exposes binary API, it is mainly used in the ping method at
  /// ConnectionService.
  BinaryAPIWrapper get binaryApi => _api;

  final Future<void> _delay = Future<void>.delayed(const Duration(seconds: 5));
  final UniqueKey _uniqueKey = UniqueKey();

  /// init method
  void initialize() {
    _api =
        BinaryAPIWrapper(uniqueKey: _uniqueKey, interceptor: Interceptor(this));

    dev.log('initialize Called');
    connectToWebSocket();
  }

  /// Make successful connection to binary web api
  Future<void> connectToWebSocket() async {
    dev.log('connectToWebSocket Called');
    try {
      await _api.close();
      dev.log('connectToWebSocket2 Called');
      await _api.run(
        onDone: (UniqueKey? uniqueKey) {
          dev.log('onDone Called');
          // Try to reconnect to the WebSocket when the connection gets closed.
          if (_uniqueKey == uniqueKey) {
            ConnectionService().checkConnectivity();
            _handleReconnect(!ConnectionService().isConnectedToInternet);
          }
        },
        onOpen: (UniqueKey? uniqueKey) {
          dev.log('onOpen Called');
          emit(ApiConnectionConnectedState(_api));
        },
        onError: (UniqueKey? uniqueKey) {
          dev.log('onError Called');
          // Try to reconnect to the WebSocket when the connection gets closed.
          ConnectionService().checkConnectivity();
          _handleReconnect(!ConnectionService().isConnectedToInternet);
        },
      );
    } on Exception catch (e) {
      dev.log('$ApiConnectionCubit connectToWebSocket() error: $e');

      emit(ApiConnectionErrorState('$e'));
    }
  }

  /// handle reconnection
  Future<void> _handleReconnect(bool isInternetLost) async {
    await _api.close();
    // ping which is closed so it will be false, Need to change the logic inside
    // the ConnectionService and update the code here.
    emit(ApiConnectionDisconnectedState(isInternetLost: isInternetLost));
  }

  /// should reconnect the WebSocket when it finishes cleaning up users data.
  Future<void> handleConnectionDisableAccountEvent(APIError error) async {
    try {
      await _api.close();
      emit(ApiConnectionForcedLogoutState(error: error));
      await _delay;
      await connectToWebSocket();
    } on Exception catch (e) {
      dev.log('$ApiConnectionCubit '
          'handleConnectionDisableAccountEvent() error: $e');

      emit(ApiConnectionErrorState('$e'));
    }
  }

  // resetting, Should investigate and if true change the name of the event.
  Future<void> _handleReset() async {
    await _api.close();

    emit(ApiConnectionDisconnectedState(
        isInternetLost: !ConnectionService().isConnectedToInternet));
  }

  @override
  void onConnected() {
    emit(ApiConnectionConnectedState(_api));
  }

  @override
  void onConnectionError(String error) {}

  @override
  void onDisconnect(DisconnectSource source) {
    _handleReset();
  }
}
