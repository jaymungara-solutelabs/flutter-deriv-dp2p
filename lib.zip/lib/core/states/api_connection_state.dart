part of 'api_connection_cubit.dart';

/// Base state for api connection
abstract class ApiConnectionState {}

/// api connection initial state
class ApiConnectionInitialState extends ApiConnectionState {}

/// api connection loading state
class ApiConnectionLoadingState extends ApiConnectionState {}

/// api connection loaded state
class ApiConnectionLoadedState extends ApiConnectionState {
  /// Initializes
}

/// api connection error state
class ApiConnectionErrorState extends ApiConnectionState {
  /// Initializes
  ApiConnectionErrorState(this.errorMessage);

  /// Error message
  final String errorMessage;
}

/// api connection connected state
class ApiConnectionConnectedState extends ApiConnectionState {
  /// init connected state
  ApiConnectionConnectedState(this.api);

  /// BinaryAPIWrapper test
  final BinaryAPIWrapper api;

  @override
  String toString() => 'DerivConnectionState(Connected)';
}

/// api connection disconnected state
class ApiConnectionDisconnectedState extends ApiConnectionState {
  /// Will emit `Disconnected` state with given parameters.
  ApiConnectionDisconnectedState({
    this.isInternetLost = false,
    this.error,
  });

  /// If true, That means the connection was closed because the device is not
  /// connected to a Wi-Fi or MobileData.
  final bool isInternetLost;

  /// The error object returned from the server.
  final APIError? error;

  /// Returns true if we need to show an error page.
  bool get shouldShowErrorPage =>
      error != null &&
      (error!.isP2PDisabled || error!.isUserUnwelcome || error!.isUserDisabled);

  @override
  String toString() => 'DerivConnectionState(Disconnected('
      'isInternetLost: $isInternetLost'
      'error: $error'
      '))';
}

/// This even is used to perform a force logout.
class ApiConnectionForcedLogoutState extends ApiConnectionState {
  /// Constructs a new ConnectionForcedLogoutState with the given error.
  ApiConnectionForcedLogoutState({
    required this.error,
  });

  /// The error object returned from the server.
  final APIError error;

  @override
  String toString() =>
      'DerivConnectionState(ConnectionForcedLogoutState($error))';
}
