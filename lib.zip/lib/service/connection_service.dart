import 'dart:async';

import 'package:connectivity/connectivity.dart';
import 'package:flutter_derivp2p_sample/core/states/api_connection_cubit.dart';

/// Connection Service
class ConnectionService {
  /// Connection Service Factory
  factory ConnectionService() => _instance;
  ConnectionService._internal();

  static final ConnectionService _instance = ConnectionService._internal();
  static const int _pingTimeout = 5;

  bool _hasConnection = true;

  /// connection change stream
  StreamController<bool> connectionChangeController =
      StreamController<bool>.broadcast();

  final Connectivity _connectivity = Connectivity();

  /// on connection change stream
  Stream<bool> get state => connectionChangeController.stream;

  /// connected state
  bool get isConnectedToInternet => _hasConnection;

  final int _connectivityCheckInterval = 5;

  late ApiConnectionCubit _apiConnectionCubit;
  Timer? _connectivityTimer;

  // phone is locked for a while the result of the `Connectivity` will be `none`
  // even if the device is connected to Wi-Fi or MobileData.
  // We need to find a way to fix this.
  Future<bool> _checkConnection(ConnectivityResult result) async {
    final bool previousConnection = _hasConnection;
    switch (result) {
      case ConnectivityResult.wifi:
      case ConnectivityResult.mobile:
        if (_apiConnectionCubit.state is! ApiConnectionConnectedState) {
          await _apiConnectionCubit.connectToWebSocket();
        }

        _hasConnection = await _ping();
        break;
      case ConnectivityResult.none:
        _hasConnection = false;
        break;
      default:
        _hasConnection = false;
        break;
    }

    if (previousConnection != _hasConnection) {
      connectionChangeController.add(_hasConnection);
    }

    return _hasConnection;
  }

  /// dispose connection service
  void dispose() {
    connectionChangeController.close();
    _connectivityTimer?.cancel();
  }

  /// init service
  Future<void> initialize(
    ApiConnectionCubit apiConnectionCubit,
  ) async {
    _apiConnectionCubit = apiConnectionCubit;
    await _connectivity.checkConnectivity();
    _connectivity.onConnectivityChanged.listen(_checkConnection);

    _startConnectivityTimer();
  }

  /// check internet connectivity
  Future<bool> checkConnectivity() async {
    final ConnectivityResult connectivityResult =
        await _connectivity.checkConnectivity();
    return _checkConnection(connectivityResult);
  }

  // Checks for change to connectivity to internet every
  // [_connectivityCheckInterval] seconds
  void _startConnectivityTimer() {
    if (_connectivityTimer == null || !_connectivityTimer!.isActive) {
      _connectivityTimer = Timer.periodic(
          Duration(seconds: _connectivityCheckInterval), (Timer timer) async {
        await checkConnectivity();
      });
    }
  }

  Future<bool> _ping() async {
    try {
      final Map<String, dynamic> response = await _apiConnectionCubit.binaryApi
          .ping()
          .timeout(const Duration(seconds: _pingTimeout));

      if (response['ping'] != 'pong') {
        return false;
      }
    } on Exception catch (_) {
      // To ensure not returning 'no connection'
      // when connection is back and ping
      // has just being called.
      if (!_hasConnection) {
        return false;
      }
    }

    return true;
  }
}
